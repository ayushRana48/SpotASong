import {useEffect, useState} from "react";
import axios from 'axios';
import { type } from "@testing-library/user-event/dist/type";
import Song from "./Song";
import Stats from "./Stats";
import {Route,Link,Routes,BrowserRouter} from "react-router-dom"
import Search from "./Search";
import Home from "./Home"
import NavBar from "./Navbar";
import SearchPanel from "./SearchPanel";
import combinedSongList from "./SongData/combinedSongList";


function App() {
    const CLIENT_ID="fdc4fdb38bf7423690bf14eed615589e"
    const REDIRECT_URI="http://localhost:3000/"
    const AUTH_ENDPOINT="https://accounts.spotify.com/authorize"
    const RESPONSE_TYPE = "token"

    const[token,setToken]=useState("")
    const[majorInfo,setMajorInfo]=useState({})
    const[microInfo,setMicroInfo]=useState({})
    const[isSelected,setIsSelected]=useState(false);
    const[isSearched,setIsSearched]=useState(false);
    const [copy,setCopy]=useState();

    const[currentPage,setCurrentPage]=useState([])
    // const[songMap,setSongMap]=useState(getAllSongs())





    useEffect(()=>{
        const hash=window.location.hash
        let token =window.localStorage.getItem("token")
        setToken(token)

        
        if(!token && hash){
            let temp=hash;

            temp= temp.split('&');

            temp=temp[0];
            temp=temp.split("=")

            temp=temp[1];
            window.location.hash=""
            window.localStorage.setItem("token",temp)
            setToken(temp)
        }

        
       
    },[])

    function toggleSelected(x){
        setIsSelected(x)
    }

    function toggleSearch(x){
        setIsSearched(x)
    }

    function getCopy(x){
        setCopy(x)
        console.log(x)
    }
    

    function changeInfo(x,y){
        console.log(x.name)
        setMajorInfo(x)
        setMicroInfo(y)
    }
    console.log(copy)



    function logOut(){
        setToken("")
        window.localStorage.removeItem("token")
    }

    function setPage(newPage){
        setCurrentPage(oldArray => [...oldArray, newPage])
    }

    function myContains(arr, elem){
        for(let i=0;i<arr.length;i++){
            if(arr[i].toLowerCase()==elem.toLowerCase()){
                return true
            }
            if(elem.toLowerCase().includes(arr[0].toLowerCase()) || elem.toLowerCase().includes(arr[1].toLowerCase())){
                // console.log(elem.toLowerCase() + "/" +arr[0].toLowerCase())
                return true;
            }
        }
        return false;
    }


     
    

 
    const search =<Search isSelected={isSelected} setPage={setPage} toggleSelected={toggleSelected} changeInfo={changeInfo} token={token} logOut={logOut}/>

    const stats=<Stats getCopy={getCopy} toggleSelected={toggleSelected} majorInfo={majorInfo} microInfo={microInfo} />

    return(
        <div> 
            {/* <button onClick={}>PressMee</button> */}
            
            {!token ?
            <div>
                <h1 className="title"> Spotify Stats</h1>
                <a className="logIn" href={`${AUTH_ENDPOINT}?client_id=${CLIENT_ID}&redirect_uri=${REDIRECT_URI}&response_type=${RESPONSE_TYPE}`}>Log in</a>
            </div>
            :
            <div>
                <div className="nav">
                    <h1 className="title"> Spotify Stats</h1>
                    <NavBar/>
                    <button className="logOut" onClick={logOut}>LogOut</button>
                </div>
                
                <Routes>
                    <Route exact path="/home" element={<Home copy={copy} toggleSearch={toggleSearch} toggleSelected={toggleSelected} currentPage ={currentPage}  setPage={setPage}/>}></Route>
                    <Route exact path="" element={<Home copy={copy} toggleSearch={toggleSearch} toggleSelected={toggleSelected} currentPage ={currentPage}  setPage={setPage}/>}></Route>
                    <Route exact path="/searchPanel" element={ <SearchPanel  toggleSearch={toggleSearch} isSelected={isSelected} toggleSelected={toggleSelected} currentPage ={currentPage} setPage={setPage} stats={stats} search = {search}/>}></Route> 

                </Routes>
                
            </div>
            
            }
     

        </div>
    )
    ;
}
export default App;


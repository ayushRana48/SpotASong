import React from "react";

export default function Stats(props){

    function copyData(){
        console.log("send Data")
        const newObject= 
            {Popularity: Math.round(props.majorInfo.popularity),
            Energy: Math.round(props.microInfo.energy*100) ,
            Danceability: Math.round(props.microInfo.danceability*100),
            Tempo:Math.round((props.microInfo.tempo-50)/1.5),
            Valence:Math.round(props.microInfo.valence*100)}

        props.getCopy(newObject)

        }
    
    return(
        <div className="statsContainer">
            <div className="vertBar"></div>
            <div className="statsInfo">
            <img className="statsImage" src={props.majorInfo.image} alt="no Img"/>
                <div className="copy">
                
                    <h3>Song: {props.majorInfo.name}</h3>
                    <img onClick={copyData} src="./images/copy.png"/>
                </div>
                
                    <p>Album: {props.majorInfo.album}</p>
                    <p>Artist: {props.majorInfo.artist}</p>
                    <p>Date: {props.majorInfo.year}</p>
                    <p>Popularity: {Math.round(props.majorInfo.popularity)}</p>
                    <p>Energy: {Math.round(props.microInfo.energy*100)}</p>
                    <p>Danceability: {Math.round(props.microInfo.danceability*100)}</p>
                    <p>Tempo: {Math.round((props.microInfo.tempo-50)/1.5)}</p>
                    <p>Valence: {Math.round(props.microInfo.valence*100)}</p>
            </div>

        </div>
    )
}
import React from "react";
import axios from 'axios';
import { getDefaultNormalizer } from "@testing-library/react";
import {Route,Link,Routes} from "react-router-dom"
import Stats from "./Stats";



export default function Song(props){


    const styles ={
        border: props.current===props.id ? "white solid 2px":"none"
    }

    async function displayInfo(){
        
     
        const {data} = await axios.get("https://api.spotify.com/v1/audio-features/" + props.id,{
            headers:{
                Authorization:`Bearer ${props.token}`
            },
            params:{
                q:"audio-features"
            }
        })
        props.toggleSelected(true);
        props.select({name:props.name, artist:props.artist,id:props.id,popularity:props.popularity, image:props.image, album:props.album, year:props.year,
             energy:data.energy, danceability:data.danceability, loudness:data.loudness, tempo:data.tempo, valence:data.valence})
        console.log(data)
    
   


    }

    const fontStyles ={
        fontSize: props.isSelected ? "min(1.3vw,1.3vh)":"min(1.7vw,1.7vh)"
    }
    console.log(props.isSelected)

    
    

    return(
        <div className="song">
  
            <h3 style={fontStyles}>{props.name}, {props.artist}</h3>
            {/* <Link to="/stats"><img style={styles} onClick={displayInfo} className="album-cover" src={props.image}/></Link> */}

            <img style={styles} onClick={displayInfo} className="album-cover" src={props.image}/>
        </div>
    )
}



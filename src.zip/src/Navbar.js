import React from "react";
import {Route,Link} from "react-router-dom"


export default function NavBar(){
    return(
        <div className="navLinks">
            <p><Link activeStyle={{color:'black'}} style={{ color:'white', textDecoration: 'none' }} to="/home">Recomendations</Link></p>
            <p><Link activeStyle={{color:'black'}} style={{ color:'white', textDecoration: 'none' }}to="/searchPanel">Search</Link></p>
        </div>
       

    )
}
import React from "react";
import Stats from "./Stats";
import Search from "./Search";
import Split from "react-split";

export default function SearchPanel(props){

    React.useEffect(()=>{props.setPage("SearchPanel")
     props.toggleSearch(false)},[])
    console.log(props.isSelected + "select")
    const x=props.search

    return(
        <div className="searchPanel">
             {props.search}
             {props.isSelected && props.stats}
                
     
            
        </div>
    )

    
        
    
}
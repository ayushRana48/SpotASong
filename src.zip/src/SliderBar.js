import React from "react";
import {Route,Link} from "react-router-dom"
import NavBar from "./Navbar";
import { Slider } from "material-ui-slider/es5/src";
import Checkbox from "react-custom-checkbox";


export default function SliderBar(props){
    console.log("yo")

    const[slide,setSlide]=React.useState({value:props.val, checked:true})

    const[val,setVal]=React.useState(50)

    React.useEffect(()=>{
        console.log(slide)
        props.change(props.name,slide)
    },[slide])

    const handleSlider = (newValue, event) => {
        setSlide({value:newValue, checked:slide.checked});
        console.log(slide)
        console.log(newValue)

      };

    const handleCheck = (newValue, event) => {
        setSlide({value:slide.value, checked:newValue});
        console.log(slide)
        console.log(newValue)
    };


    

    return(
            <div className="sliderTest">
                <Checkbox className="checkBox" checked={true} onChange={handleCheck} style={{borderColor:"rgb(160, 50, 17)"}}></Checkbox>
                <Slider className="slider" disabled={!slide.checked} value={props.val} color="rgb(21, 201, 21)"
                 onChange={handleSlider}></Slider>
                 {/* <button onClick={test}>test</button> */}
                <p className="sliderName">{props.name}</p>
            </div>
        )
}
import React from "react";

export default function SearchedSongs(props){
    const name=props.name;
    const image=props.image;
    const artist=props.artist;
    const album=props.album;

    return(
        <div className="searchedSong">
            <div className="searchAlbum">
                <img className="searchAlbumPic" src={image}/>
                <div className="searchSongInfo">
                    <h3>{name}</h3>
                    <p>{album}</p>
                    <p>by {artist}</p>
                </div>
                
            </div>
            <button className="addSong">Add Song</button>
        </div>
    )
}
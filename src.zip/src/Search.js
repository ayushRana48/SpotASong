import {useEffect, useState} from "react";
import axios from 'axios';
import { type } from "@testing-library/user-event/dist/type";
import Song from "./Song";
import Stats from "./Stats";
import {Route,Link,Routes,BrowserRouter} from "react-router-dom"

function Search(props) {
    const CLIENT_ID="fdc4fdb38bf7423690bf14eed615589e"
    const REDIRECT_URI="http://localhost:3000/"
    const AUTH_ENDPOINT="https://accounts.spotify.com/authorize"
    const RESPONSE_TYPE = "token"

    const[token,setToken]=useState("")
    const[search,setSearch]=useState("")
    const[songs,setSongs]=useState([])

    const[selectedID,setSelectedID]= useState("");



    async function selectSong(x){
        setSelectedID(x.id)
        props.toggleSelected(true)

           props.changeInfo({name:x.name, artist:x.artist,popularity:x.popularity, image:x.image,album:x.album.name, year:x.album.release_date},
            {danceability:x.danceability, energy:x.energy, loudness:x.loudness, tempo:x.tempo, valence:x.valence})
    }

    const searchSong = async (e) => {
        setSelectedID("")
        e.preventDefault()
        try{
        const {data} = await axios.get("https://api.spotify.com/v1/search",{
            headers:{
                Authorization:`Bearer ${props.token}`
            },
            params:{
                q:search,
                type:"track"
            }
        })

        const temp=[];
        for(let i=0; i<6;i++){
            temp[i]=data.tracks.items[i]
        }
        setSongs(temp)
    }
    catch(err){
        console.log(err)
    }
    }


    function songsListt(){
        if(songs[0]){
            let newArr=[]
            for(let i=0; i<songs.length;i++){
                const x=songs[i];
                newArr.push(<Song isSelected = {props.isSelected} toggleSelected={props.toggleSelected} num={i} select={selectSong} current={selectedID} token = {props.token} image={x.album.images[0].url} album={x.album} year={x.release_date} name={x.name} id={x.id} artist = {x.artists[0].name} popularity={x.popularity}/>)
            }
            return newArr
        }
        else{
            return []
        }
    }

    const songList = songsListt()



    return(
        <div className="searchComp"> 
            <div>
                <form className="search" onSubmit={searchSong}>
                    <input className="searchText" type="text" onChange={e=>setSearch(e.target.value)} placeholder="search song"></input>
                    <button className="searchButton" type={"submit"}>Search</button>
                 </form>
                <div className="songs">
                    {songList}
                </div>                    
            </div>
        </div>
    )
    
}

export default Search;
import React from "react";
import {Route,Link} from "react-router-dom"
import NavBar from "./Navbar";
import { Slider } from "material-ui-slider/es5/src";
import Checkbox from "react-custom-checkbox";
import SliderBar from "./SliderBar";
import Carousel from "react-elastic-carousel";
import Genre from "./Genre";
import finalSongList from "./SongData/finalSongList";
import combinedSongList from "./SongData/combinedSongList";
import SearchedSongs from "./SearchedSong";

export default function Home(props){
    console.log("yo")

    const[settings,setSettings]=React.useState({Popularity: {value:50, checked:true},
        Energy: {value:50, checked:true},                       
        Danceability: {value:50, checked:true},
        Tempo: {value:50, checked:true},
        Valence: {value:50, checked:true}})
    const [currGenre,setCurrGenre]= React.useState("Any")

    const[topSongs,setTopSongs]=React.useState([])


    React.useEffect(()=>{props.setPage("Home")
                         props.toggleSelected(false)},[])

    React.useEffect(()=>{console.log(settings)},[settings])

    function changeSettings(name, properties){
        console.log(name)
        console.log(properties)
        setSettings((x) => {return {...x, [name] : properties}})
    }

    function handleGenre(click){
        console.log("Click" +click)
        setCurrGenre(click)
        console.log(currGenre)
        
    }



    function getTotalStats(){
        let total=0;
        if(settings.Popularity.checked){
            console.log(settings.Popularity.checked)
            total+=1;
        }
        if(settings.Energy.checked){
            total+=1;
        }
        if(settings.Danceability.checked){
            total+=1;
        }
        if(settings.Tempo.checked){
            total+=1;
        }
        if(settings.Valence.checked){
            total+=1;
        }
        console.log(total)
        return total;
    }

    function filterGenre(){
        console.log("search")
        let filteredList=[]
        if(currGenre==="Any"){
            console.log("yoooo")
            return finalSongList.songs
        }
        for(let i=0;i<finalSongList.songs.length;i++){
            const currentSong=finalSongList.songs[i];
            let genreCount=0;
            for(let j=0;j<currentSong.genre.length;j++){
                if(currentSong.genre[j]===currGenre){
                    genreCount+=1;
                }
            }
            if((genreCount/parseFloat(currentSong.genre.length))>0.4){
                filteredList.push(currentSong)
            }
        }
        console.log(filteredList)
        return filteredList
        

    }

    function calculateScore(){
        console.log(settings)
        const songList=filterGenre()
        const totalStats= getTotalStats();
        const popularity=settings.Popularity.value;
        const energy = settings.Energy.value/100.0;
        const danceability= settings.Danceability.value/100.0;
        const valence= settings.Valence.value/100.0;
        const tempo=(settings.Tempo.value*1.5)+50


        let scoreList=[]
        
        for(let i=0;i<songList.length;i++){
            const currSong=songList[i]
            let score=0;
            if(settings.Popularity.checked){

                const diff=Math.abs(currSong.popularity-popularity)/parseFloat(popularity)
                // console.log(diff)
                score+=(1-diff);
                // console.log(score)
            }
            if(settings.Energy.checked){

                const diff=Math.abs(currSong.energy-energy)/parseFloat(energy)
                // console.log(diff)
                score+=(1-diff);
                // console.log(score)
            }
            if(settings.Danceability.checked){

                const diff=Math.abs(currSong.danceability-danceability)/parseFloat(danceability)
                // console.log(diff)
                score+=(1-diff);
                // console.log(score)
            }
            if(settings.Valence.checked){

                const diff=Math.abs(currSong.valence-valence)/parseFloat(valence)
                // console.log(diff)
                score+=(1-diff);
                // console.log(score)
            }
            if(settings.Tempo.checked){

                const diff=Math.abs(currSong.tempo-tempo)/parseFloat(tempo)
                // console.log(diff)
                score+=(1-diff);
            }
            score=score/parseFloat(totalStats);
            // console.log(score)
            
            const newObj= {...currSong, "score" : score}
            scoreList.push(newObj)
            
        }

        

        scoreList.sort(function(a,b){
            if(a.score>b.score){
                return -1;
            }
            else if(a.score<b.score){
                return 1;
            }
            else{
                return 0;
            }
        })

        console.log(scoreList)
        setTopSongs(getSongs(scoreList))
        return scoreList;


        

    }

    function getSongs(songList){
        let arr=[]
        for(let i=0;i<60;i++){
            arr.push(songList[i])
        }
        return arr;


    }

    function pasteData(){
        console.log(props.copy)
        setSettings(function(x){
            const newObj= {Popularity:{value: props.copy.Popularity,checked: x.Popularity.checked},
                          Energy:{value: props.copy.Energy,checked: x.Energy.checked},
                          Danceability:{value: props.copy.Danceability,checked: x.Danceability.checked},
                          Tempo:{value: props.copy.Tempo,checked: x.Tempo.checked},
                          Valence:{value: props.copy.Valence,checked: x.Valence.checked}}
            return newObj
            
        }
        )
            
    }
   
    const breakPoints =[
        {width:1, itemsToShow:5}
    ]

    const genres =["Any","Pop","EDM","Rap","R&B","Latin","Rock","Metal","Country","Folk","Classical","Blues","Other"]
    const genreList = genres.map(name => <Genre click={()=>handleGenre(name)} name={name} current={currGenre} />)

    const songsWithScore= topSongs.map(x =><SearchedSongs name={x.name} album={x.album} artist={x.artist} image={x.image} />)

   


    return(
        <div>
            <h1 className="homeTitle">
                Find God (Songs)
            </h1> 
            <div className="paste">
                <SliderBar  val = {settings.Popularity.value} change={changeSettings} name="Popularity"></SliderBar>
                {props.copy && <img onClick={pasteData} src="./images/paste.png"/>}
            </div>
            <SliderBar val = {settings.Energy.value} change={changeSettings} name="Energy"></SliderBar>
            <SliderBar val = {settings.Danceability.value} change={changeSettings} name="Danceability"></SliderBar>
            <SliderBar val = {settings.Tempo.value} change={changeSettings} name="Tempo"></SliderBar>
            <SliderBar val = {settings.Valence.value} change={changeSettings} name="Valence"></SliderBar>  
            <Carousel style ={{color:"green"}}className="genres" breakPoints={breakPoints} loop={true} >
                {genreList}
            </Carousel>  
           <button onClick={calculateScore}className="searchSong">Search</button>
          
           {topSongs.length>0 && <div className="testOverFlow">
                <div className="searchSongGrid">
                    {songsWithScore}

                </div>
           </div>}


        </div>
    )
}

